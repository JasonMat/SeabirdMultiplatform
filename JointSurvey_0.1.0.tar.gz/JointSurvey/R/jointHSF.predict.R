#' jointHSF.predict: Bayesian prediction from pooled survey data.
#' @description MCMC and JAGS modelling of joint survey data. Several different models are possible.
#' @author Jason Matthiopoulos
#' @param results The output object of th jointHSF command
#' @param Xpred A matrix with covariate data in the columns
#' @param Dist A dataframe with distance data in the columns
#' @param mask A matrix the size of the map which has zero fo land and 1 for sea
#' @param Colonies A matrix with the locations and sizes of the colonies modelled (xloc in col 1, yloc in col2 and size in col 3)
#' @param aLocs A vector of integers declaring the positions, in the `results`, of the environmental covariate parameters
#' @param cLocs A vector of integers declaring the positions, in the `results`, of the colony ranging parameters
#' @return A list with two maps, one for the expected usage and one for the associated standard deviation
#' @details This fuction redeploys the `colambda` function repeatedly, using different parameterisations from the sample of the joint posterior distribution
#' @export

jointHSF.predict<-function(results, aLocs, cLocs, Xpred, Dist, mask, Colonies)
{
  a_trials<-as.matrix(as.mcmc(results))
  a_trials<-a_trials[seq(1,length(a_trials[,1]),length.out = min(100,length(a_trials[,1]))),] # Thinning of the chains
  a_t<-length(a_trials[,1])

  xd<-dim(mask)[1]
  yd<-dim(mask)[2]
  preds<-array(0,c(a_t,xd,yd))

  for(i in (1:a_t)) preds[i,,]<-colambda(Colonies, acoef=a_trials[i,aLocs],ccoef=a_trials[i,cLocs], Xpred, Dist,mask)
  muMap<-mask*0
  sdMap<-mask*0
  for(i in 1:xd)
  {
    for(j in 1:yd)
    {
      muMap[i,j]<-mean(preds[1:a_t,i,j])
      sdMap[i,j]<-sqrt(var(preds[1:a_t,i,j]))
    }
  }

  return(list("muMap"=muMap,"sdMap"=sdMap))
}

