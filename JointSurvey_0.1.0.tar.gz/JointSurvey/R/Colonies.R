#' Colonies
#'
#' @docType data
#' @usage Colonies
#' @details  An example data-frame of the locations and sizes of three colonies on the TestlandscapeDat map.
#'
#' @format Rdata
#' @keywords datasets
"Colonies"
