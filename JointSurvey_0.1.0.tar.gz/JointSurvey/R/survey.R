#' survey: Transect generation for rectangular region.
#' @description Generates regular transects with a particular design profile, within a rectangular region of predefined boundaries.
#' @author Jason Matthiopoulos
#' @param xlim,ylim Two-element vectors containing the limits of the rectangular region (in arbitrary coordinates)
#' @param le The spacing between successive sampling points on the transect (in units of length)
#' @param disp The perpendicular distance between transects (in units of length)
#' @param df The orientation of the transects with reference to the rectangular boundaries. It is an angle measured in rad anti-clockwise from the horizontal.
#' @param mask An optional matrix that can be used to mask out survey points.
#' @return A nx2 matrix of sampling coordinates (where n is the number of points that were required to survey the rectangular study region)
#' @examples
#' pts<-survey(c(0,150),c(0,150),1,10,10)
#' plot(pts)
#' @details The coordinate system used must be distance-preserving because Euclidean distances are employed for spacing the transects.
#' @export


survey<-function(xlim,ylim, le, disp, df=0, mask=NULL)
{
  xmin<-xlim[1]
  xmax<-xlim[2]
  ymin<-ylim[1]
  ymax<-ylim[2]
  x0<-(xmax-xmin)/2
  y0<-(ymax-ymin)/2

  pts<-expand.grid(seq(xmin-4*xmax,xmax+4*xmax,le),seq(ymin-4*ymax,ymax+4*ymax,disp))
  x<-pts[,1]
  y<-pts[,2]
  d<-sqrt((x0-x)^2+(y0-y)^2)
  fi<-atan2(y-y0,x-x0)
  x<-x0+d*cos(fi+df)
  y<-y0+d*sin(fi+df)

  inds=(x>=xmin)*(x<=xmax)*(y>=ymin)*(y<=ymax)==1
  x<-x[inds]
  y<-y[inds]

  if(is.null(mask)==FALSE)
  {
    include<-mask[cbind(round(x),round(y))]
    x<-x[as.logical(include)]
    y<-y[as.logical(include)]
  }

  return(cbind(x,y))
}
