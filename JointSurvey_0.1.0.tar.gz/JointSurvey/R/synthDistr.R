#' synthDistr: Point generation given underlying intensity map for IPP
#' @description Allows the generation of occurrences from the map of an intensity function lambda, provided as a matrix, allowing for overdispersion.
#' @author Jason Matthiopoulos
#' @param lambda A matrix of non-negative values (intensities)
#' @param q The overdispersion parameter.
#' @return A matrix with the same dimensions as lambda containing integer counts
#' @details The value q cannot be <1. Set to 1 for a Poisson and >1 for overdispersed values from a negative binomial. When q>1, no zero values are allowed in lambda.
#' @export

synthDistr<-function (lambda,q=1) {
  di<-dim(lambda)
  las<-c(lambda)
  n<-length(las)
  if (q==1)
    {map<-rpois(n, las)
 } else {
    map<-rnbinom(n, size=(las/(q-1)), mu=las)}
  return(matrix(map,di))
}
