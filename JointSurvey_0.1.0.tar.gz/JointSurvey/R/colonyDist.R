#' colonyDist:Distance from colony map
#' @description A distance-from-colony based on Euclidean distances. An optional mask layer may be provided to exclude land. In future versions, the mask layer will be used to generate at-sea distances, instead of Euclidean.
#' @author Jason Matthiopoulos
#' @param xo,yo Scalars or vectors. The x and y locations of the colony.
#' @param map The map on which distances are required. To be used as a mask, it must have values 0 on land and 1 at sea.
#' @param masked An optional argument that declares whether the map matrix should be used to exclude land. If so, then the map matrix needs to have entries 1 for sea and 0 for land. If masked, the distances on land are set to the masked value.
#' @return A matrix of distances. If xo and yo are vectors, then an array is returned with layers of distances.
#' @details The coordinate system used must be distance-preserving because Euclidean distances are employed for spacing the transects. The centred argument is useful for constructing distances in colonies that are variably "shaded" by land. It allows several different colonies to have the same mean for the frequency distribution of distances.
#' @export

colonyDist<-function(xo,yo,map,masked=NULL)
{
  xm<-dim(map)[1]
  ym<-dim(map)[2]
  coords<-expand.grid(1:xm,1:ym)

  di<-array(NA, dim=c(length(xo),xm,ym))
  for(i in 1:length(xo))
  {
    dists<-sqrt((coords[,1]-xo[i])^2+(coords[,2]-yo[i])^2)
    di[i,,]<-matrix(dists,xm,ym)
    if(is.null(masked)==FALSE)
    {
      di[i,,]<-di[i,,]*map
      di[i,,]<-di[i,,]+abs(map-1)*masked
    }
  }

  return(di)
}

