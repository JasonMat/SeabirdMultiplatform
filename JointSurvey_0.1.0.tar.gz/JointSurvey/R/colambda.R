#' colambda: Spatial intensity for collection of colonies and covariates
#' @description Generates aggregate layer of expected usage from multiple colonies and covariates
#' @author Jason Matthiopoulos
#' @param cols A data frame with the coordinates and sizes of colonies
#' @param acoef The habitat variable coefficients
#' @param ccoef The density dependence coefficients
#' @param Xpred A dataframe with covariate data in the columns
#' @param Dist A dataframe with distance data in the columns
#' @param mask A matrix the size of the map which has zero fo land and 1 for sea
#' @return A map with the same dimensions as `mask` representing intensity for all accessible points in space.
#' @details The `Dist` dataframe has points in space as its rows and different colonies as its columns.
#' @export

colambda<-function(cols, acoef,ccoef, Xpred, Dist,mask)
{

  J<-length(cols[,1])
  dec<-Dist

  u3<-Dist[,1]*0
  for(i in 1:J)
  {
    u3<-u3+cols[i,3]/(1+ccoef[3]*Dist[,i])
  }


  coefs<-c(acoef,ccoef[1],ccoef[2])

  # Loop to process individual distance maps from array dis
  for(i in 1:J)
  {
    # Implements distance-decay function
    dec[,i]<-exp(c(t(acoef)%*%t(Xpred))+ccoef[1]*Dist[,i]+ccoef[2]*Dist[,i]*u3)
    # Masks for land masses
    dec[,i]<-dec[,i]*c(mask)
    dec[is.nan(dec[,i]),i]<-0
    # Normalises to null usage for colony
    dec[,i]<-cols[i,3] *dec[,i]/sum(dec[,i])
  }

  lambda<-apply(dec, 1, sum)
  return(matrix(lambda,nrow=dim(mask)[1], ncol=dim(mask)[2]))
}



