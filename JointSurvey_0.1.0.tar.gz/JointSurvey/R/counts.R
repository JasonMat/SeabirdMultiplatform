#' counts: Sampling of species distribution along given transects.
#' @description Produces simulated counts of individuals along a set of sampling locations, based on the underlying (but unknown distribution of the species)
#' @author Jason Matthiopoulos
#' @param tr A nx2 matrix with coordinates of sampling points along the transects
#' @param u The underlying distribution to be surveyed
#' @param w The effective detection distance from the transect
#' @param l The spacing between successive survey points (This is related to speed along transect)
#' @param p The detection probability of each bird within the effective detection area of the survey point.
#' @return A vector of length n
#' @details The algorithm assumes that the cell of the map has a unitary area (area=1). The detection probability `p` captures availability bias.
#' @export

counts<-function(tr, u, w, l, p)
{
  ss<-4
  mx<-1
  my<-1
  Mx<-dim(u)[1]
  My<-dim(u)[2]
  dets<-0*tr[,1] # Initialises detections vector
  for(i in 1:length(tr[,1]))
  {
    fi<-runif(ss, 0, 2*pi) #n random angles
    ro<-runif(ss, 0, w) # n random distances from transect point
    sample<-cbind(pmin(Mx, pmax(mx, round(tr[i,1]+ro*cos(fi)))), pmin(My,pmax(my, round(tr[i,2]+ro*sin(fi))))) # A sample of coordinates within a circle around transect point
    indis<-round(mean(u[sample])*(l*2*w)) #Approximate number of animals in rectangle centred at survey point
    dets[i]<-rbinom(1,indis, p)
  }
return(dets)
}

