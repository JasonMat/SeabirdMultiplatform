#' jointHSF: Bayesian inference on pooled survey data.
#' @description MCMC and JAGS modelling of joint survey data. Several different models are possible.
#' @author Jason Matthiopoulos
#' @param count The number of individuals counted at each step of the transect
#' @param X A matrix of covariate data. Rows represent survey point, columns represent covariates
#' @param dist A matrix of distances from each colony. Rows represent survey point, columns represent colonies
#' @param surv A vector of index values pointing to the survey serial number from which the count arose
#' @param ll Distance between successive transect points.
#' @param w Width of strip transect.
#' @param p0 Probability of detection of each indivudual at distance zero.
#' @param N A vector of colony sizes.
#' @param disp Distance between every pair of points in the dataset. A square matrix only used for spatial models.
#' @return A JAGS object of results from the model run.
#' @examples
#' pts<-survey(c(0,150),c(0,150),1,10,10)
#' plot(pts)
#' @details The coordinate system used must be distance-preserving because Euclidean distances are employed for spacing the transects.
#' @export

jointHSF<-function(count, X, dist, surv, ll, w, p0, N, model="IPP", disp=NULL, ABS=c(1000,1000,1000))
{
# =============== POISSON MODEL ===================
  IPP <- "model{
  ### MAIN LOOP ###
  for(i in 1:n)
  {
    for(j in 1:J)
    {
      lambdaC[i,j]<-exp(a0+sum(a[1:nX]*X[i,1:nX])+c[1]*dist[i,j]+sum(c[2]*dist[i,j]*N[1:J]/(1+c[3]*dist[i,1:J])))
    }
    # Process
    lambda[i]<-sum(N[1:J]*lambdaC[i,1:J])
    indis[i]~dpois(lambda[i])
    indisA[i]<-round(indis[i]*ll[surv[i]]*2*w[surv[i]])
    # Observation
    count[i]~dbinom(p0[surv[i]],indisA[i])
  }

  # PRIORS #
  a0~dnorm(0,0.01)
  for(i in 1:nX) {a[i]~dnorm(0,0.001)}

  c1~dunif(0,0.02)
  c[1]<--c1
  c[2]~dunif(0,0.0000001)
  c[3]~dunif(0,0.1)

  #for(i in 1:nS) {p0[i]~dbeta(10,10)}

  #data# n, nX, X, count, surv, nS, ll,w, p0, dist, N, J
  #monitor# a0, a, c

  }"


  # =============== NEGATIVE BINOMIAL MODEL ===================

NEGBIN <- "model{
  ### MAIN LOOP ###
  for(i in 1:n)
  {
    for(j in 1:J)
    {
      lambdaC[i,j]<-exp(a0+sum(a[1:nX]*X[i,1:nX])+c[1]*dist[i,j]+sum(c[2]*dist[i,j]*N[1:J]/(1+c[3]*dist[i,1:J])))
    }
    # Process
    lambda[i]<-sum(N[1:J]*lambdaC[i,1:J])

    #Reparameterisation of negative binomial as a Gamma-Poisson mixture
    shape[i]<-lambda[i]*p/(1-p)
    rate[i]<-p/(1-p)
    mu[i]~dgamma(shape[i],rate[i])
    indis[i]~dpois(mu[i])
    indisA[i]<-round(indis[i]*ll[surv[i]]*2*w[surv[i]])
    # Observation
    count[i]~dbinom(p0[surv[i]],indisA[i])
    }

  # PRIORS #
  a0~dnorm(0,0.01)
  for(i in 1:nX) {a[i]~dnorm(0,0.001)}

  c1~dunif(0,0.02)
  c[1]<--c1
  c[2]~dunif(0,0.0000001)
  c[3]~dunif(0,0.1)

  p~dbeta(1,1)
  od<-1/p #Overdispersion parameter


  #for(i in 1:nS) {p0[i]~dbeta(10,10)}

  #data# n, nX, X, count, surv, nS, ll,w, p0, dist, N, J

  #monitor# a0, a, c, od
}"

# =============== SPATIAL MODEL ===================

SPATIAL <- "model{

### MAIN LOOP ###

for(i in 1:n)
{
  #eps[i]~dnorm(mu[i],0.001)
  for(j in 1:J)
  {
  lambdaC[i,j]<-exp(a0+sum(a[1:nX]*X[i,1:nX])+c[1]*dist[i,j]+sum(c[2]*dist[i,j]*N[1:J]/(1+c[3]*dist[i,1:J]))+eps[i])
  }
  # Process
  lambda[i]<-sum(N[1:J]*lambdaC[i,1:J])
  indis[i]~dpois(lambda[i])
  indisA[i]<-round(indis[i]*ll[surv[i]]*2*w[surv[i]])
  # Observation
  count[i]~dbinom(p0[surv[i]],indisA[i])
}

# SPATIAL RANDOM EFFECT #
for(i in 1:n)
{
  for(k in 1:n)
  {
  cov[i,k]<-c01*exp(-c02*disp[i,k])
  }
}

eps[1:n]~dmnorm.vcov(mu[],cov)


# PRIORS #
a0~dnorm(0,1)
for(i in 1:nX) {a[i]~dnorm(0,0.001)}

c01~dunif(0,0.01)
c02~dunif(0,0.1)
c1~dunif(0,0.1)
c[1]<--c1
c[2]~dunif(0,0.0000001)
c[3]~dunif(0,0.1)

#for(i in 1:nS) {p0[i]~dbeta(10,10)}

#data# n, nX, X, count, surv, nS, ll,w, p0, disp, N, J, mu, dist, csL
#monitor# a0, a, c01,c02,c

}"

  n<-length(X[,1]) # Number of rows in data
  nX<-length(X[1,]) # Number of covariates
  nS<-max(surv) # The number of surveys in the pooled data
  mu<-rep(0,n) # Vector of means for spatial random effect



  results <-run.jags(eval(str2expression(model)),
                   n.chains=4, adapt=ABS[1],burnin=ABS[2], sample=ABS[3],
                   thin=1, method="parallel",
                   modules=c("glm"))

  return(results)
}
