#' JointSurvey: Integrated Bayesian analysis of transect surveys.
#'
#' This package provides functions for the integrated Bayesian analysis of transect survey data that have originated from surveys of differring design. The applications are motivated from a Marine Scotland grant enquiring about the inferrential feasibility of joint analyses of current and historic seabird surveys.
#' @docType package
#' @name JointSurvey
#' @author Jason Matthiopoulos
#'
#' @section JointSurvey functions:
#' \link{survey},
#' \link{synthDistr}
#' \link{colonyDist}
#' \link{counts}
#' \link{jointHSF}
#' \link{jointHSF.predict}
#'
#' @section JointSurvey data-sets:
#' \link{TestlandscapeDat}
#'
#' @examples
#' # FITTING A GENERALISED FUNCTIONAL RESPONSE MODEL (see Matthiopoulos et al. 2011)

#' @references References for this implementation:
#' @references Matthiopoulos et al. (2011) Generalized functional responses for species distributions. Ecology 92 (3), 583-589
#' @references Matthiopoulos et al. (2015) Establishing the link between habitat selection and animal population dynamics. Ecological Monographs 85 (3), 413-436
#' @references Background references:
#' @references Morales et al. (2010) Building the bridge between animal movement and population dynamics Phil. Trans. R. Soc. B 2010 365 2289-2301; DOI: 10.1098/rstb.2010.0082.

NULL
