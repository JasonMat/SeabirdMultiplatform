#' TestlandscapeDat
#'
#' @docType data
#' @usage TestlandscapeDat
#' @details  Contains three covariate layers (stored as matrices). The first `u1` corresponds to bathymetry an the second `u2` refers to an aspect of sediment. The third, `land` has the indicator values of 1 for sea and 0 for land.
#'#' @examples
#' image(u1)
#' @format Rdata
#' @keywords datasets
"TestlandscapeDat"
