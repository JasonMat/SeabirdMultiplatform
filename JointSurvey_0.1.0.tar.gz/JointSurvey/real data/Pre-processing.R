# Use this code to prepare data for incusion in the JointSurvey package.


# COLONY DATA =======================
realCols<-data.frame(
"Species"=c("Kittiwake","Kittiwake","Kittiwake", "Kittiwake", "Guillemot", "Guillemot", "Guillemot", "Guillemot", "Gannet","GBB gull", "GBB gull"),

"Size"=c(4206, 4651, 9444, 11265,  21812, 34182,  48929,  22077,  75259,  36,  79),

"x"=c(527521, 553712,	 548857,	 573576,	 527521, 553712,	 548857,	 573576,	 522376,	 573576,	 527521),

"y"=c(6226859,6197231,6307509,6370348,6226859,6197231,6307509,6370348,6214786,6370348,6226859))


fr<-400 # Desired number of rows in map
fc<-round(fr/1.75) # Corresponding number of columns (preserving ratio of original map)
ncols<-1370
nrows<-2400
cellsize<-100
xllcorner<-482969.7245
yllcorner<-6151101.5246
realCols[,3]<-round((realCols[,3]-xllcorner)*fc/(cellsize*ncols))
realCols[,4]<-round((realCols[,4]-yllcorner)*fr/(cellsize*nrows))
plot(realCols[,3],realCols[,4])
xr<-1:fr
yr<-1:fc

par(mfrow=c(2,2))
# DEPTH MASK =====================================
# ncols         1370
# nrows         2400
# xllcorner     482969.7245
# yllcorner     6151101.5246
# cellsize      100
# NODATA_value  -9999


nr<-2400
nc<-1370
dmask1<- scan("~/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/real data/sa_bathy_mask.txt")
dmask2<-matrix(dmask1,ncol=nr,nrow=nc)
dmask<-dmask2[seq(1,nc,length.out=fc),seq(nr,1,length.out=fr)]
image(yr,xr,dmask, zlim=c(-10,0))
points(realCols[,3], realCols[,4], pch=16, col="Brown", cex=2)


# DEPTH =====================================
# ncols         1370
# nrows         2400
# xllcorner     482969.7245
# yllcorner     6151101.5246
# cellsize      100
# NODATA_value  -9999

nr<-2400
nc<-1370
depth1 <- scan("~/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/real data/sa_bathy_30n.txt")
depth2<-matrix(-pmin(0,depth1),ncol=nr,nrow=nc)
depth<-depth2[seq(1,nc,length.out=fc),seq(nr,1,length.out=fr)]
image(yr,xr,depth, zlim=c(0,100))
contour(yr,xr,dmask, add=TRUE, levels=c(0,1))
points(realCols[,3], realCols[,4], pch=16, col="Brown", cex=2)

# SEDIMENT =====================================
# ncols         1370
# nrows         2400
# xllcorner     482969.7245
# yllcorner     6151101.5246
# cellsize      100
# NODATA_value  -9999
nr<-2400
nc<-1370
sed1<- scan("~/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/real data/Sediment.txt")
sed2<-matrix(sed1,ncol=nr,nrow=nc)
sed<-sed2[seq(1,nc,length.out=fc),seq(nr,1,length.out=fr)]
image(yr,xr,sed, zlim=c(0,5))
contour(yr,xr,dmask, add=TRUE, levels=c(0,1))
points(realCols[,3], realCols[,4], pch=16, col="Brown", cex=2)

sedLayer<-array(0,c(6,fc,fr))
for(i in 1:6)
{
  sedLayer[i,,]<-as.numeric(sed==(i-1))
}

# WINDFARMS =====================================
# ncols         1370
# nrows         2400
# xllcorner     482969.7245
# yllcorner     6151101.5246
# cellsize      100
# NODATA_value  -9999
nr<-2400
nc<-1370
wf<-array(data=NA, dim=c(9,fc,fr))
wfTot<-matrix(0,fc,fr)
for(i in 1:9)
{
  wf1<- scan(paste("~/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/real data/wf_0",i,".txt", sep=""))
  wf2<-matrix(wf1,ncol=nr,nrow=nc)
  wf[i,,]<-wf2[seq(1,nc,length.out=fc),seq(nr,1,length.out=fr)]
  wfTot<-wfTot+wf[i,,]
}
image(yr,xr,wfTot)
contour(yr,xr,dmask, add=TRUE, levels=c(0,1))
points(realCols[,3], realCols[,4], pch=16, col="Brown", cex=2)
par(mfrow=c(1,1))

colN=xr
rowN=yr
save(realCols, dmask,depth, sed,sedLayer,wf, colN, rowN,file="/Users/Jason/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/data/NorthSeaDat.rdata")

# Then type from inside the package
# NorthSeaDat<-load("/Users/Jason/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/data/NorthSeaDat.rdata")
# use_data(NorthSeaDat, overwrite=TRUE)

