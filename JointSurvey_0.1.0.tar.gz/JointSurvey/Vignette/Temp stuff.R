
## An inhomogeneous Poisson model
We will use JAGS (ref) as an inferrential engine. We have developed the function `jointHSF` which implements and runs several different probabilistic models coded in JAGS. First, we will examine how to set up a call to `jointHSF` and demonstrate this with the simplest of its packaged models, the Inhomogeneous Poisson Process. We will pair that biological model with an observation model that exactly reflects the design parameters (i.e. span and detectability) of the `r length(ll)` surveys conducted above. The model first requires a matrix `X` of covariate data containing transect points along the rows and distinct covariates along the columns. The second requirement is for a vector `surv` which declares which survey each location comes from. Internally, this will allow the model to match the survey characteristics of detectability, with the observed count. The `count` vector is the third required input, this is a vector of counts at each transect point. The call to the function `jointHSF` combines these data with the detectability parameters $w,p_0$ and the spacing between survey points $l$. These parameter values are used internally to scale the value of the spatial intensity function at the location of the survey point, into an expected count of animals within the effective area of detection.

```{r jointHSF_IPP, message=FALSE, warning=FALSE, results=FALSE}

# Coercion of a covariate data-frame into a matrix
X<-as.matrix(data[,4:5])
# Survey tags for each point in the data
surv<-data$sv
# Response data
count<-data$counts
# Distance data
dist<-matrix(0,n,J)
for(j in 1:J) dist[,j]<-dis[cbind(rep(j,n),round(data$x),round(data$y))]
# Colony sizes
N<-Colonies[,3]

# Model fitting
resultsIPP<-jointHSF(count, X, dist, surv, ll, w, p0, N, model="IPP")
# Extraction of summaries for posteriors
sumsIPP<-summary(resultsIPP)
```

The MCMC results and statistical summaries from the model fit are stored in the names `resultsIPP` and `sumsIPP` respectively.

## Summaries and diagnostics
Here, we can pull together a comparison between the parameter values estimated from the above code (along with 95% credible intervals), together with the true values that were used in the simulation above.

| Parameter | True values | 2.5% limit | Median | 97.5% limit |
  | :-----:   |:-----------:|:----------:|:------:|:-----------:|
  | $a_1$     | `r round(a1,2)`| `r round(sumsIPP[2,1],2)`  | `r round(sumsIPP[2,2],2)` |`r round(sumsIPP[2,3],2)` |
  | $a_2$     | `r round(a2,2)`| `r round(sumsIPP[3,1],2)`  | `r round(sumsIPP[3,2],2)` |`r round(sumsIPP[3,3],2)` |
  | $c_0$     | `r round(c0,2)`| `r round(sumsIPP[4,1],2)`  | `r round(sumsIPP[4,2],2)` |`r round(sumsIPP[4,3],2)` |
  | $c_1$     | `r round(c1,2)`| `r round(sumsIPP[5,1],2)`  | `r round(sumsIPP[5,2],2)` |`r round(sumsIPP[5,3],2)` |
  | $c_2$     | `r round(c2,2)`| `r round(sumsIPP[6,1],2)`  | `r round(sumsIPP[6,2],2)` |`r round(sumsIPP[6,3],2)` |

  For this model, all the true habitat parameter values are retrieved correctly, however, the colony ranging parameters are a little harder to pin down.

## Spatial predictions from the model
Although it would be theoretically possible to embed the spatial prediction functionality into the model fitting, the sheer size of the maps over which prediction will be required makes this option less ideal. Instead, we can extract a sensible sample from the posterior of the JAGS output by using `as.mcmc` from the library `coda`. This functionality is incorporated in the `jointHSF.predict` function, which requires the fitted model object (in this case `resultsIPP`), a matrix of prediction covariates (here called `Xpred`) and a template of the map (here `land`). The prediction covariates matrix needs to have columns for all the covariates of the model, preceded by a column of 1's, standing in for the value of the "covariate" to the model's intercept. The predictions for mean and standard deviation of the intensity are returned in matrix format, in the dimensions of the map template, so they can be plotted directly as images.

```{r fig.height=3, fig.width=8, fig.align='center',warning=FALSE}
Xpred<-cbind(rep(1,length(c(u1))),c(u1),c(u2))
preds<-jointHSF.predict(resultsIPP, aLocs=c(1,2,3), cLocs=c(4,5,6), Xpred=Xpred, Dist=Dist, mask=land, Colonies=Colonies)

par(mfrow=c(1,3))
image(x,y,lambda/land, col=pal(50),
      main="True intensity")
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
image(x,y,preds$muMap/land, col=pal(50),
      main="Estimated intensity")
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
image(x,y,preds$sdMap/(preds$muMap*land), col=pal(50),
      main="Uncertainty map")
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
par(mfrow=c(1,1))
```



# More advanced joint inference for the distribution of species from pooled survey data
The `jointHSF` function has access to more advanced models intented to deal with overdispersion, explicit spatial relationships and gaps in the covariate layers.

## Modelling overdispersion with a negative binomial model
The model with negative binomial likelihood can be called by altering the model name in the `jointHSF` function. The summaries from this model report on the degree of overdispersion in the data.

```{r jointHSF_NB, message=FALSE, warning=FALSE, results=FALSE}
resultsNB<-jointHSF(count, X, dist, surv, ll, w, p0, N, model="NEGBIN")
sumsNB<-summary(resultsNB)

```
| Parameter | True values | 2.5% limit | Median | 97.5% limit |
  | :-----:   |:-----------:|:----------:|:------:|:-----------:|
  | $a_1$     | `r round(a1,2)`| `r round(sumsNB[2,1],2)`  | `r round(sumsNB[2,2],2)` |`r round(sumsNB[2,3],2)` |
  | $a_2$     | `r round(a2,2)`| `r round(sumsNB[3,1],2)`  | `r round(sumsNB[3,2],2)` |`r round(sumsNB[3,3],2)` |
  | $c_0$     | `r round(c0,2)`| `r round(sumsNB[4,1],2)`  | `r round(sumsNB[4,2],2)` |`r round(sumsNB[4,3],2)` |
  | $c_1$     | `r round(c1,2)`| `r round(sumsNB[5,1],2)`  | `r round(sumsNB[5,2],2)` |`r round(sumsNB[5,3],2)` |
  | $c_2$     | `r round(c2,2)`| `r round(sumsNB[6,1],2)`  | `r round(sumsNB[6,2],2)` |`r round(sumsNB[6,3],2)` |
  | $q$     | `r round(od,2)`| `r round(sumsNB[7,1],2)`  | `r round(sumsNB[7,2],2)` |`r round(sumsNB[7,3],2)` |


  ```{r echo=FALSE, fig.align='center', fig.height=3, fig.width=8, warning=FALSE}
par(mfrow=c(1,1))
Xpred<-cbind(rep(1,length(c(u1))),c(u1),c(u2))
preds<-jointHSF.predict(resultsNB, aLocs=c(1,2,3), cLocs=c(4,5,6), Xpred=Xpred, Dist=Dist, mask=land, Colonies=Colonies)

par(mfrow=c(1,3))
image(x,y,lambda/land, col=pal(50),
      main="True intensity")
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
image(x,y,preds$muMap/land, col=pal(50),
      main="Estimated intensity")
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
image(x,y,preds$sdMap/(preds$muMap*land), col=pal(50),
      main="Uncertainty map")
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
par(mfrow=c(1,1))
```
