
# Importing data
load("/Users/Jason/Dropbox/2. Science/1. Papers/(2 In progress) Sessility to mobility/Code/Am Nat 3rd revision/Model_data_Ems.rdata")

# Normalising covariates
md2$Tdepth<-abs(md2$depth-max(md2$depth))
#md2$slibNL<-log((md2$slibNL+1)/mean(md2$slibNL+1))
md2$Tslib<-log((md2$slibNL)+1)

# Extent of box
Xmin<-min(md2$xrd)
Xmax<-max(md2$xrd)
Ymin<-min(md2$yrd)
Ymax<-max(md2$yrd)

# Number of cells in grid
unit<-2000
ndx<-ceiling((Xmax-Xmin)/unit)
ndy<-ceiling((Ymax-Ymin)/unit)

# Rescaled coordinates
md2$Txrd<-round(ndx*(md2$xrd-Xmin)/(Xmax-Xmin))
md2$Tyrd<-round(ndy*(md2$yrd-Ymin)/(Ymax-Ymin))

# Extent of rescaled box
XminT<-min(md2$Txrd)
XmaxT<-max(md2$Txrd)
YminT<-min(md2$Tyrd)
YmaxT<-max(md2$Tyrd)

# Labels of cells in each direction
x<-seq(XminT,XmaxT,length.out=ndx)
y<-seq(YminT,YmaxT,length.out=ndy)


# Grid generation and covariate layers
u1<-u2<-cnt<-matrix(0,ndx,ndy)
for(i in 1:length(md2$Txrd))
{
  u1[md2$Txrd[i],md2$Tyrd[i]]<-u1[md2$Txrd[i],md2$Tyrd[i]]+md2$Tdepth[i]
  u2[md2$Txrd[i],md2$Tyrd[i]]<-u2[md2$Txrd[i],md2$Tyrd[i]]+md2$Tslib[i]
  cnt[md2$Txrd[i],md2$Tyrd[i]]<-cnt[md2$Txrd[i],md2$Tyrd[i]]+1
}
land<-pmin(cnt,1)

u1<-u1/(cnt-(1-land))
u2<-u2/(cnt-(1-land))

library(RColorBrewer)
cols <- brewer.pal(3, "BrBG")
pal <- colorRampPalette(cols)
par(mfrow=c(1,2))
image(x,y,u1/land, col=pal(30))
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
image(x,y,u2/land, col=pal(10))
contour(x,y,land, levels=c(0.5),add=TRUE,drawlabels=FALSE)
par(mfrow=c(1,1))

save(land, u1, u2, Xmin,Xmax,Ymin,Ymax,ndx,ndy,x,y,file="/Users/Jason/Dropbox/2. Science/2. Grants/2019 Marine Scotland joint surveys/Code/JointSurvey/data/TestlandscapeDat.rdata")


